import os, sys, re, json
import urllib2
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class LinkProvider(object):
    def __init__(self, web_content_provider):
        self.web_content_provider = web_content_provider

    def get_links(self):
        content= self.web_content_provider.get_page('https://pastebin.com/raw/7TsNLk7Y')
        return json.loads(content)

    def get_acestreams(self):
        return self.get_links()
