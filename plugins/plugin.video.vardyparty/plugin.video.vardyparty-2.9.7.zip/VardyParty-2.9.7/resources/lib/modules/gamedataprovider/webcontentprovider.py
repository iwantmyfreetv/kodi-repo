import os
import sys
import re
import json
import urllib2
import httplib
reload(sys)
                                            
try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class WebContentProvider(object):
    def __init__(self):
        self.cache = {}

    def get_page(self, url):
        if (url in self.cache):
            log("WebContentProvider cache-hit for " + url, 3)
            return self.cache[url]
        content = self.__get_page(url)
        if (content != ''):
            self.cache[url] = content
        return content

    def __get_page(self, url):
        headers = { 'User-Agent' : 'Mozilla/5.0' }
        content = ""
        try:
            request = urllib2.Request(url, None, headers)
            response = urllib2.urlopen(request, timeout= 16)
            content = response.read()
            #cookie= response.info().getheader('Set-Cookie')
            #if (cookie!=None and cookie!=''):
            #    cookie= cookie.split(";")[0]
            #    log("COOKIE: '"+cookie+"'", 3)
            #    headers['Cookie']= cookie
            #    request = urllib2.Request(url, None, headers)
            #    response2 = urllib2.urlopen(request, timeout= 16)
            #    content2 = response2.read()
            #    if (content!=content2):
            #        log("DIFFERENT CONTENT!  "+url,3)
            #        content= content2
            #        log(content2,3)
        except urllib2.HTTPError as err:
            log("FAIL: WebContentProvider.__get_page url=" + url, 3)
        except urllib2.HTTPError, e:
            log('FAIL: WebContentProvider.__get_page url=' + url + ' code=' + str(e.code),3)
        except urllib2.URLError, e:
            log('FAIL: WebContentProvider.__get_page url=' + url + ' reason=' + str(e.reason),3)
        except httplib.HTTPException, e:
            log('FAIL: WebContentProvider.__get_page Http-Exception. url=' + url,3)
        except Exception:
            log('FAIL: WebContentProvider.__get_page Exception url=' + url, 3)
        return content

