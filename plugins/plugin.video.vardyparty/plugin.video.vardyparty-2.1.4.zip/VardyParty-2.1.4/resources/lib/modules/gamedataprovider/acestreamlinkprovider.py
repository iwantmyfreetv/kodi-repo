import os
import sys
import re
import json
import urllib2
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class AcestreamLinkProvider(object):
    def __init__(self, game_data_provider, reddit_stream_provider, footybite_stream_provider, rojadirecta_stream_provider):
        self.game_data_provider = game_data_provider
        self.reddit_stream_provider = reddit_stream_provider
        self.footybite_stream_provider = footybite_stream_provider
        self.rojadirecta_stream_provider = rojadirecta_stream_provider

    def normalise(self, link_set):
        normalised = {}
        for url, title, source, type in link_set:
            if (url not in normalised or normalised[url] == None):
                normalised[url] = (title, source, type)
        normalised_link_set = []
        for url in normalised:
            (title, source, type) = normalised[url]
            normalised_link_set.append((url, title, source, type))
        return normalised_link_set

    def cleanse_title(self, title):
        time_pattern = r'(?:\[\d\d\:\d\d\s\w+\]\s)?([\w\s\-]+)'
        live_game_pattern= r'\s([\w\s]+\s\-\s[\w\s]+)\s'
        clean_title_matches = re.findall(live_game_pattern, title)
        if (len(clean_title_matches) > 0):
            return clean_title_matches[0]
        else:
            live_game_matches= re.findall(time_pattern, title)
            if (len(live_game_matches)>0):
               return live_game_matches[0]
        return title

    def normalise_non_competition_games(self, games):
        normalised = {}
        count = {}
        for title, streams in games:
            clean_title = self.cleanse_title(title)
            if (clean_title not in normalised):
                normalised[clean_title] = title
            stream_count = 0
            if (clean_title in count):
                stream_count = count[clean_title]
            count[clean_title] = stream_count + streams
        normalised_titles = []
        for normalised_title in normalised:
            title = normalised[normalised_title]
            normalised_titles.append((normalised_title, count[normalised_title]))
        return normalised_titles

    def get_acestreams(self, game_id):
        game_data = self.game_data_provider.get_game_data()
        acestream_items = []
        for competition in game_data:
            for game in competition['events']:
                if (str(game['id']) == str(game_id)):
                    fooybite_url = game['redditEventLink']
                    if (fooybite_url != None):
                        footybite_links = self.footybite_stream_provider.get_acestreams(fooybite_url, game)
                        acestream_items.extend(footybite_links)
                    rojadirecta_links = self.rojadirecta_stream_provider.get_acestreams(game)
                    acestream_items.extend(rojadirecta_links)
                    reddit_links = self.reddit_stream_provider.get_acestreams(game)
                    acestream_items.extend(reddit_links)
        return self.normalise(acestream_items)

    def get_non_competition_rojadirecta_games(self):
        games_not_in_competition_with_streams = []
        games = self.rojadirecta_stream_provider.get_all_games()
        for game_title, link_content in self.game_data_provider.get_rojadirect_games_not_in_competitions(games):
            streams = self.rojadirecta_stream_provider.get_acestream_items_from_content(link_content)
            log("Roja NOT IN: " + game_title + " stream=" + str(len(streams)),3)
            if (len(streams) > 0):
                games_not_in_competition_with_streams.append((game_title, len(streams)))
        return games_not_in_competition_with_streams

    def get_non_competition_reddit_games(self):
        games_not_in_competition_with_streams = []
        games = self.reddit_stream_provider.get_all_games()
        for game_not_in_competition in self.game_data_provider.get_reddit_games_not_in_competitions(games):
            streams = self.reddit_stream_provider.get_acestream_items_from_submission_id(game_not_in_competition['submission_id'])
            log("Reddit NOT IN: " + game_not_in_competition['title'] + " stream=" + str(len(streams)),3)
            if (len(streams) > 0):
                games_not_in_competition_with_streams.append((game_not_in_competition['title'], len(streams)))
        return games_not_in_competition_with_streams

    def get_non_competition_games(self):
        games_not_in_competition_with_streams = []
        reddit_games= self.get_non_competition_reddit_games()
        rojadirecta_games= self.get_non_competition_rojadirecta_games()
        #log("reddit:"+str(len(reddit_games)), 3)
        #log("roja:"+str(len(rojadirecta_games)), 3)
        games_not_in_competition_with_streams.extend(reddit_games)
        games_not_in_competition_with_streams.extend(rojadirecta_games)
        return self.normalise_non_competition_games(games_not_in_competition_with_streams)

    def get_acestream_items_from_title(self, title):
        acestream_items = []
        title= self.cleanse_title(title)
        acestream_items.extend(self.reddit_stream_provider.get_acestream_items_from_title(title))
        acestream_items.extend(self.rojadirecta_stream_provider.get_acestream_items_from_title(title))
        return  self.normalise(acestream_items)


