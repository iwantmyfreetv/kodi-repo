import os, sys, re
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class GameClient(object):
    def __init__(self, game_data_provider, acestream_link_provider):
        self.game_data_provider= game_data_provider
        self.acestream_link_provider=acestream_link_provider

    def prepare_inprogess_components(self, game):
        prefix= self.game_data_provider.game_score(game)+"  "
        suffix="  ("+str(self.game_data_provider.get_game_time(game))+" mins)"
        return prefix, suffix

    def prepare_finished_components(self, game):
        prefix= self.game_data_provider.game_score(game)+"  "
        suffix= ""
        return prefix, suffix

    def prepare_future_components(self, game):
        prefix= game["startTime"]+"  "
        suffix= ""
        return prefix, suffix

    def prepare_title(self, game, streamsForGame):
        if (self.game_data_provider.is_in_progress(game)):
            prefix, suffix = self.prepare_inprogess_components(game)
        elif (self.game_data_provider.is_finished(game)):
            prefix, suffix = self.prepare_finished_components(game)
        else:
            prefix, suffix = self.prepare_future_components(game)
        if (not self.game_data_provider.is_finished(game)):
            suffix+= "  ["+str(streamsForGame)+" Streams]"
        title= prefix+ game['name']+ suffix
        return title

    def get_games(self, competition_id):
        games= []
        gameData= self.game_data_provider.get_game_data()
        for competition in gameData:
            if (str(competition['id'])==str(competition_id)):
                for game in competition['events']:
                    if (self.game_data_provider.is_active_game(game)):
                        number_of_streams= len(self.acestream_link_provider.get_acestreams(game['id']))
                        if (number_of_streams>0):
                            title = self.prepare_title(game, number_of_streams)
                            games.append((title, game['id']))
        return games

    def get_non_competition_games(self):
        return self.acestream_link_provider.get_non_competition_games()
