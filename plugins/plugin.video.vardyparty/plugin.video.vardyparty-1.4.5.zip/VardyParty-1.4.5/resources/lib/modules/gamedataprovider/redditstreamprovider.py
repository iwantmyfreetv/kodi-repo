import os, sys, re, json
import urllib2
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class RedditStreamProvider(object):
    def get_reddits(self):
        content= self.web_content_provider.get_page('https://pastebin.com/raw/C5gN0E2C')
        return json.loads(content)

    def __init__(self, subRedditEvents, web_content_provider, game_data_provider):
        self.events = subRedditEvents
        self.web_content_provider = web_content_provider
        self.reddits= self.get_reddits()
        self.game_data_provider= game_data_provider
    
    def get_score(self, score):
        if (str(score!="")):
            plural= "s"
            if (score==1):
                plural=""
            return "  ("+str(score)+" vote"+plural+")"
        return ""
 
    def get_acestreams(self, game):
        acestream_items= []
        games= self.get_all_games()
        for reddit_event in games:
            if (self.game_data_provider.game_title_matches_a_game_team(reddit_event['title'], game)):
                acestream_items.extend(self.get_acestream_items_from_submission_id(reddit_event['submission_id']))
        return acestream_items

    def get_submisson_id_from_title(self, title):
        submission_id= ''
        games= self.get_all_games()
        for reddit_event in games:
            if (title in reddit_event['title']):
                submission_id= reddit_event['submission_id']
        return submission_id

    def get_acestream_items_from_title(self, title):
        acestream_items= []
        submission_id= self.get_submisson_id_from_title(title)
        if (submission_id != None and submission_id!=''):
            acestream_items.extend(self.get_acestream_items_from_submission_id(submission_id))
        return acestream_items

    def get_acestream_items_from_submission_id(self, submission_id):
        acestream_items= []
        reddit_acestream_links = self.events.get_event_links(submission_id)
        for score, quality, acelink in reddit_acestream_links:
            acestream_items.append((acelink, quality+self.get_score(score), 'reddit', 'acestream'))
        return acestream_items

    def get_all_games(self):
        games= []
        for reddit in self.reddits:
            subreddit= reddit['subreddit']
            subreddit_events= []
            try:
                subreddit_events= self.events.get_events(subreddit)
            except:
                log('Reddit '+subreddit+' may have been banned', 3)
            for reddit_event in subreddit_events:
                games.append(reddit_event)
        return games
