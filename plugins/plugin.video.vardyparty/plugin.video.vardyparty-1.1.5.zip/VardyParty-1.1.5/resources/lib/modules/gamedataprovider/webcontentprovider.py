import os, sys, re, json
import urllib2
#handler=urllib2.httphandler(debuglevel=1)
#opener = urllib2.build_opener(handler)
#urllib2.install_opener(opener)
reload(sys)
                                            
try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class WebContentProvider(object):
    def get_page(self, url):
        headers = { 'User-Agent' : 'Mozilla/5.0' }
        request = urllib2.Request(url, None, headers)
        response = urllib2.urlopen(request)
        content= response.read()
        return content
