import os, sys, re, json
import urllib2
#handler=urllib2.httphandler(debuglevel=1)
#opener = urllib2.build_opener(handler)
#urllib2.install_opener(opener)
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class RedditStreamProvider(object):
    def get_reddits(self):
        headers = { 'User-Agent' : 'Mozilla/5.0' }
        request = urllib2.Request("https://pastebin.com/raw/C5gN0E2C", None, headers)
        response = urllib2.urlopen(request)
        content= response.read()
        reddits = json.loads(content)
        return reddits

    def __init__(self, subRedditEvents):
        self.events = subRedditEvents
        self.reddits= self.get_reddits()
    
    def get_score(self, score):
        if (str(score!="")):
            plural= "s"
            if (score==1):
                plural=""
            return "  ("+str(score)+" vote"+plural+")"
        return ""

    def is_reddit_event_the_game(self, reddit_event, game):
        game_title=reddit_event['title'].lower()
        return (
            game_title.find(game['homeTeam']['name'].lower()) > 0 
            or 
            game_title.find(game['awayTeam']['name'].lower()) > 0)
 
    def get_acestreams(self, game):
        acestream_items= []
        for reddit in self.reddits:
            subreddit= reddit['subreddit']
            subreddit_events= []
            try:
                subreddit_events= self.events.get_events(subreddit)
            except:
                log('Reddit '+subreddit+' may have been banned', 3)
            for reddit_event in subreddit_events:
                if (self.is_reddit_event_the_game(reddit_event, game)):
                    reddit_url= reddit_event['submission_id']
                    reddit_acestream_links = self.events.get_event_links(reddit_url)
                    for score, quality, acelink in reddit_acestream_links:
                        acestream_items.append((acelink, quality+self.get_score(score)))
        return acestream_items

