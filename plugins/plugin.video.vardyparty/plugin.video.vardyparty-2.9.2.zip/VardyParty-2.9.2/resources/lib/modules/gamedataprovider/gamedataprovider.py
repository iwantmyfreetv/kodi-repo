import os
import sys
import re
import json
import time
import urllib2
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class GameDataProvider(object):
    def __init__(self, web_content_provider):
        self.web_content_provider = web_content_provider
        content = self.web_content_provider.get_page('https://darsh.sportsvideo.net/api/top-matches-footybit?timezone=UTC')
        if (content != None and content != ''):
            self.game_data = json.loads(content)
            self.game_data_loaded = True
        else:
            self.game_data = []
            self.game_data_loaded = False

    def get_game_data(self):
        return self.game_data

    def is_active_game(self, game):
        mins = self.get_game_time(game)
        active = ((not self.is_finished(game)) or mins < 170)
        #log(game['homeTeam']['name']+" - "+game['awayTeam']['name']+" mins=
        #"+str(mins)+" active="+str(active), 3)
        return active

    def is_in_progress(self, game):
        return game['status']['type'] == "inprogress"

    def is_finished(self, game):
        return game['status']['type'] == "finished"

    def game_score(self, game):
        home_score = game["homeScore"]['current']
        away_score = game['awayScore']['current']
        if (home_score != '' and away_score != ''):
            return home_score + " - " + away_score
        return ''

    def get_score_str(self, game):
        score_str = ''
        score = self.game_score(game)
        if (score != None and score != ''):
            score_str = "(" + score + ")  "
        return score_str

    def get_game_time(self, game):
        mins = int((time.time() - game["startTimestamp"]) / 60)
        if (mins > 45 and mins <= 60):
            mins = 45
        elif (mins > 60):
            mins = mins - 15
        if (self.is_in_progress(game) and mins > 100):
            mins = mins - 5
            if (mins > 105 and mins <= 110):
                mins = mins = 105
        return mins

    def get_game(self, game_id):
        found_game = None
        for competition in self.game_data:
            for game in competition['events']:
                if (game['id'] == int(game_id)):
                    found_game = game
        return found_game

    def get_game_name(self, game_id):
        game = self.get_game(game_id)
        game_name = ''
        if (game != None):
            game_name = game['name']
        return game_name

    def get_game_score(self, game_id):
        game_score = None
        game = self.get_game(game_id)
        if (game != None):
            game_score = self.game_score(game)
        return game_score

    def get_competition_title(self, competition, numberOfLiveEvents):
        plural = "s"
        if (numberOfLiveEvents == 1):
            plural = ""
        title = competition['name'] + "  [" + str(numberOfLiveEvents) + " game" + plural + "]"
        return title

    def get_all_games(self):
        games = []
        for competition in self.game_data:
            for game in competition['events']:
                games.append(game)
        return games

    def get_reddit_games_not_in_competitions(self, reddit_games):
        games = self.get_all_games()
        reddit_games_not_in_game_data_competitions = []
        for reddit_game in reddit_games:
            found = False
            for game in games:
                if (self.game_title_matches_a_game_team(reddit_game['title'], game)):
                    found = True
                    break
            if (not found):
                reddit_games_not_in_game_data_competitions.append(reddit_game)
        return reddit_games_not_in_game_data_competitions

    def game_title_matches_a_game_team(self, game_title, game):
        game_title = game_title.lower()
        home_team = game['homeTeam']['name'].lower()
        away_team = game['awayTeam']['name'].lower()
        if (game_title.find(home_team) >= 0 or game_title.find(away_team) >= 0):
            return True
        names = game_title.split(" - ")
        if (len(names) == 2):
            return (home_team.find(names[0]) >= 0 or away_team.find(names[1]) >= 0)
        return False


