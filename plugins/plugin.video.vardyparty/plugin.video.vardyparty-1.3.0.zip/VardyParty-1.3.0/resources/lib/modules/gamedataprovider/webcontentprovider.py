import os
import sys
import re
import json
import urllib2
reload(sys)
                                            
try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class WebContentProvider(object):
    def __init__(self):
        self.cache = {}

    def get_page(self, url):
        if (url in self.cache):
            return self.cache[url]
        content = self.__get_page(url)
        self.cache[url] = content
        return content

    def __get_page(self, url):
        headers = { 'User-Agent' : 'Mozilla/5.0' }
        request = urllib2.Request(url, None, headers)
        response = urllib2.urlopen(request)
        content = response.read()
        return content

