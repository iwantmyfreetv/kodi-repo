import os
import sys
import re
import json
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class StreamClient(object):
    def __init__(self, game_data_provider, acestream_link_provider):
        self.game_data_provider = game_data_provider
        self.acestream_link_provider = acestream_link_provider

    def get_streams(self, game_id):
        streams = []
        acestreams = self.acestream_link_provider.get_acestreams(game_id)
        game_name = self.game_data_provider.get_game_name(game_id)
        for acestream_url, title in acestreams:
            if (title == None or title == ""):
                title = "Unknown Stream"
            title = title.replace("\\", "")
            streams.append((acestream_url, title, game_name + " - " + title))
        return streams

    def get_reddit_streams(self, submission_id):
        return self.acestream_link_provider.get_acestream_items_from_submission_id(
            submission_id)