import os, sys, re, json, time
import urllib2
#handler=urllib2.HTTPHandler(debuglevel=1)
#opener = urllib2.build_opener(handler)
#urllib2.install_opener(opener)
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class GameDataProvider(object):
    def __init__(self, web_content_provider):
        self.web_content_provider = web_content_provider
        content= self.web_content_provider.get_page('http://darsh.sportsvideo.net/api/top-matches-footybit?timezone=UTC')
        self.game_data = json.loads(content)

    def get_game_data(self):
        return self.game_data

    def is_active_game(self, game):
        mins= self.get_game_time(game)
        return (not self.is_finished(game) or mins < 135)

    def is_in_progress(self, game):
        return game['status']['type']=="inprogress"

    def is_finished(self, game):
        return game['status']['type']=="finished"

    def game_score(self, game):
        return game["homeScore"]['current']+" - "+game['awayScore']['current']

    def get_game_time(self, game):
        mins= int((time.time()-game["startTimestamp"])/60)
        if (mins > 45 and mins <= 60):
            mins= 45
        elif (mins > 60):
            mins=mins - 15
        if (self.is_in_progress(game) and mins > 100):
            mins= mins -5
            if (mins > 105 and mins <= 110):
                mins= mins= 105
        return mins

    def get_game_name(self, game_id):
        game_name= None
        for competition in self.game_data:
            for game in competition['events']:
                if (game['id']==int(game_id)):
                    game_name= game['name']
        return game_name

    def get_competition_title(self, competition, numberOfLiveEvents):
        plural= "s"
        if (numberOfLiveEvents==1):
            plural= ""
        title=  competition['name'] + "  ["+str(numberOfLiveEvents)+" game"+plural+"]"
        return title

