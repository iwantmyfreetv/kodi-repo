import os
import sys
import re
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class GameClient(object):
    def __init__(self, game_data_provider, acestream_link_provider):
        self.game_data_provider = game_data_provider
        self.acestream_link_provider = acestream_link_provider

    def prepare_inprogess_components(self, game):
        prefix = self.game_data_provider.get_score_str(game)
        suffix = "  (" + str(self.game_data_provider.get_game_time(game)) + " mins)"
        return prefix, suffix

    def prepare_finished_components(self, game):
        prefix = self.game_data_provider.get_score_str(game)
        suffix = ""
        return prefix, suffix

    def prepare_future_components(self, game):
        prefix = game["startTime"] + "  "
        suffix = ""
        return prefix, suffix

    def prepare_title(self, game, streamsForGame):
        if (self.game_data_provider.is_in_progress(game)):
            prefix, suffix = self.prepare_inprogess_components(game)
        elif (self.game_data_provider.is_finished(game)):
            prefix, suffix = self.prepare_finished_components(game)
        else:
            prefix, suffix = self.prepare_future_components(game)
        if (not self.game_data_provider.is_finished(game)):
            plural = "s"
            if (streamsForGame <= 1):
                plural = ""
            suffix+= "  [" + str(streamsForGame) + " stream" + plural + "]"
        title = prefix + game['name'] + suffix
        return title

    def prepare_non_competition_game_title(self, game_title, stream_count):
        plural = "s"
        if (stream_count <= 1):
            plural = ""
        return game_title + " [" + str(stream_count) + " stream" + plural + "]"

    def get_games(self, competition_id):
        games = []
        gameData = self.game_data_provider.get_game_data()
        for competition in gameData:
            if (str(competition['id']) == str(competition_id)):
                for game in competition['events']:
                    if (self.game_data_provider.is_active_game(game)):
                        number_of_streams = len(self.acestream_link_provider.get_acestreams(game['id']))
                        if (number_of_streams > 0):
                            title = self.prepare_title(game, number_of_streams)
                            games.append((title, game['id']))
        return games

    def get_non_competition_games(self):
        games = []
        game_items = self.acestream_link_provider.get_non_competition_games()
        for game_title, stream_count in game_items:
            games.append((game_title, self.prepare_non_competition_game_title(game_title, stream_count), None, "title"))
        return games

    def get_all_games(self):
        acestream_items = []
        gameData = self.game_data_provider.get_game_data()
        for competition in gameData:
            for game in competition['events']:
                if (self.game_data_provider.is_active_game(game)):
                    number_of_streams = len(self.acestream_link_provider.get_acestreams(game['id']))
                    if (number_of_streams > 0):
                        title = self.prepare_title(game, number_of_streams)
                        acestream_items.append((title, game['id'], competition['logo'], "gameid"))
        acestream_items.extend(self.get_non_competition_games())
        return acestream_items
