import os
import sys
import re
import json
import urllib2
reload(sys)
                                            
try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class SoccerstreamsStreamProvider(object):
    def __init__(self, web_content_provider, external_content_loader):
        self.web_content_provider = web_content_provider
        self.external_content_loader= external_content_loader

    def get_acestreams(self, url, game):
        matches = []
        match= re.search("(\/[\w\-]+\/\d+)$", url)
        if (match):
            event_id= match.groups(0)[0]
            json_url= "https://darsh.sportsvideo.net/api/event/soccerstreams"+event_id
            log("soccer-streams-net game json: "+json_url, 3)
            content = self.web_content_provider.get_page(json_url)
            if (content!= None and content!=''):
                event_data= json.loads(content)
                if ('message' not in event_data and 'streamResourceId' in event_data):
                    stream_source_id= event_data['streamResourceId']
                    content= self.web_content_provider.get_page('https://darsh.sportsvideo.net/api/event/streams/'+source_event_id)
                    stream_data= json.loads(content)
                    for stream in stream_data:
                        if (stream['stream_type']=='Acestream'):
                            url= stream['stream_link']
                            title= stream['channel_name']
                            log('SoccerStreams '+title+" "+url, 3) 
                            matches.extend(self.external_content_finder.find(url, title, game, "soccerstreams"))
        return matches