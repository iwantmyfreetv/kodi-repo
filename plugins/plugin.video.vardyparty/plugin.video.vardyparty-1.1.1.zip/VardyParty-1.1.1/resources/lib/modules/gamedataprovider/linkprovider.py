import os, sys, re, json
import urllib2
#handler=urllib2.HTTPHandler(debuglevel=1)
#opener = urllib2.build_opener(handler)
#urllib2.install_opener(opener)
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class LinkProvider(object):
    def get_links(self):
        headers = { 'User-Agent' : 'Mozilla/5.0' }
        request = urllib2.Request('https://pastebin.com/raw/7TsNLk7Y', None, headers)
        response = urllib2.urlopen(request)
        content= response.read()
        return json.loads(content)

    def get_acestreams(self):
        return self.get_links()
