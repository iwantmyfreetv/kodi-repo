import os
import sys
import re
import json
import urllib2
reload(sys)
                                            
try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class FootyBiteStreamProvider(object):
    def __init__(self, web_content_provider, external_content_loader):
        self.web_content_provider = web_content_provider
        self.external_content_loader = external_content_loader

    def get_raw_acestreams_from_links_tagged_acestream(self, content, game):
        link_pattern = r'<a[\s\w="]+href="(https?:\/\/[\w.\/\-]+)"[\s\w="]*>([\w\s\-&;()]+)<\/a>\s*<span class="badge badge-primary">Acestream<\/span>'
        external_links = re.findall(link_pattern, content)
        log("get_raw_acestreams_from_links_tagged_acestream: " + str(len(external_links)),3)
        links = []
        for url, title in external_links:
            links.extend(self.external_content_loader.find(url, title, game, "footybites"))
        return links

    def get_acestreams(self, url, game):
        content = self.web_content_provider.get_page(url)
        script_pattern = r'stream\((\d+)\)'
        embedded_ids = re.findall(script_pattern, content)
        links = []
        has = (len(embedded_ids) > 0)
        log("find_embedded_content_links: " + str(has),3)
        if has:
            id = embedded_ids[0]
            external_content = self.web_content_provider.get_page("https://ifootballonline.com/public/default/auth/fixture-embed-test/id/" + id)
            external_acestream_links = self.get_raw_acestreams_from_links_tagged_acestream(external_content, game)
            links.extend(external_acestream_links)
        return links
