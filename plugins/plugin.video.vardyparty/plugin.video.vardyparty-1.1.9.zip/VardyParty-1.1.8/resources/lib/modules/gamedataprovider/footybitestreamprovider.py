import os, sys, re, json
import urllib2
#handler=urllib2.httphandler(debuglevel=1)
#opener = urllib2.build_opener(handler)
#urllib2.install_opener(opener)
reload(sys)
                                            
try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class FootyBiteStreamProvider(object):
    def __init__(self, web_content_provider):
        self.web_content_provider = web_content_provider

    def find_inline_acestream_links(eelf, content):
        pattern= r'<a href="(acestream:\/\/\w+)"[\s\w="]*>([\w\s\[\]]+)<\/a>'
        matches= re.findall(pattern, content)
        links=[]
        for match in matches:
            links.append((match[0],match[1]))
        return links

    def find_raw_acestream_links(eelf, content):
        pattern= r'(acestream://\w+)'
        matches= re.findall(pattern, content)
        links=[]
        for match in matches:
            links.append((match, None))
        return links

    def find_acestreams_in_external_links(eelf, content):
        link_pattern= r'<a href="([\w:\/\.]+)"[\w="\s]+>ACESTREAM.+<\/a>'
        external_links= re.findall(link_pattern, content)
        links= []
        for external_link in external_links:
            external_content= self.web_content_provider.get_page(external_link)
            links.extend(self.find_raw_acestream_links(external_content))
        return links

    def get_raw_acestreams_from_links_tagged_acestream(self, content):
        link_pattern= r'<a[\s\w="]+href="(https?:\/\/[\w.\/-]+)"[\s\w="]*>([\w\s-]+)<\/a>\s*<span class="badge badge-primary">Acestream<\/span>'
        external_links= re.findall(link_pattern, content)
        links= []
        for match in external_links:
            log(match[0],3)
            external_content= self.web_content_provider.get_page(match[0])
            raw_acestream_links= self.find_raw_acestream_links(external_content)
            for url, empty_title in raw_acestream_links:
                links.append((url, match[1]))
        return links

    def find_embedded_content_links(self, content):
        script_pattern= r'<script>stream\((\d+)\)<\/script>'
        embedded_ids= re.findall(script_pattern, content)
        links=[]
        if (len(embedded_ids)>0):
            id= embedded_ids[0]
            external_content= self.web_content_provider.get_page("https://ifootballonline.com/public/default/auth/fixture-embed-test/id/"+id)
            external_acestream_links= self.get_raw_acestreams_from_links_tagged_acestream(external_content)
            links.extend(external_acestream_links)
        return links

    def get_acestreams(self, url):
        content= self.web_content_provider.get_page(url)
        matches=[]
        matches.extend(self.find_inline_acestream_links(content))
        matches.extend(self.find_raw_acestream_links(content))
        matches.extend(self.find_acestreams_in_external_links(content))
        matches.extend(self.find_embedded_content_links(content))
        return matches