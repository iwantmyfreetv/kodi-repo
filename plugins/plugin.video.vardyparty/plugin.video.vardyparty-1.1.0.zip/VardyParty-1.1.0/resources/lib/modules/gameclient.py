import os, sys, re, time
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class GameClient(object):
    def __init__(self, gameDataProvider, acestreamLinkProvider):
        self.gameDataProvider= gameDataProvider
        self.acestreamLinkProvider=acestreamLinkProvider

    def get_game_time(self, game):
        mins= int((time.time()-game["startTimestamp"])/60)
        if (mins > 45 and mins <= 60):
            mins= 45
        elif (mins > 60):
            mins=mins - 15
        return mins

    def prepare_inprogess_components(self, game):
        prefix=game["homeScore"]['current']+" - "+game['awayScore']['current']+"  "
        mins = self.get_game_time(game)
        suffix="  ("+str(mins)+" mins)"
        return prefix, suffix

    def prepare_finished_components(self, game):
        suffix= ""
        prefix=game["homeScore"]['current']+" - "+game['awayScore']['current']+"  "
        return prefix, suffix

    def prepare_future_components(self, game):
        prefix= game["startTime"]+"  "
        suffix= ""
        return prefix, suffix

    def prepare_title(self, game, streamsForGame):
        if (game['status']['type']=="inprogress"):
            prefix, suffix = self.prepare_inprogess_components(game)
        elif (game['status']['type']=="finished"):
            prefix, suffix = self.prepare_finished_components(game)
        else:
            prefix, suffix = self.prepare_future_components(game)
        if (game['status']['type']!="finished"):
            suffix+= "  ["+str(streamsForGame)+" Streams]"
        title= prefix+ game['name']+ suffix
        return title

    def get_games(self, competition_id):
        gameData= self.gameDataProvider.get_game_data()
        games=[]
        for competition in gameData:
            if (str(competition['id'])==str(competition_id)):
                for game in competition['events']:
                    mins= int((time.time()-game["startTimestamp"])/60)
                    if (game['status']['type']!="finished" and mins < 120):
                        number_of_streams= len(self.acestreamLinkProvider.get_acestreams(game['id']))
                        if (number_of_streams>0):
                            title = self.prepare_title(game, number_of_streams)
                            games.append((title, game['id']))
        return games
