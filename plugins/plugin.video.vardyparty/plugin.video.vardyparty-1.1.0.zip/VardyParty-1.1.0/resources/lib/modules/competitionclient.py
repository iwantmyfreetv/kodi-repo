import os, sys, re, time
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class CompetitionClient(object):
    def __init__(self, gameDataProvider, acestreamLinkProvider):
        self.gameDataProvider= gameDataProvider
        self.acestreamLinkProvider= acestreamLinkProvider

    def get_number_of_streaming_events(self, i):
        liveEvents= 0
        for game in i['events']:
            mins= int((time.time()-game["startTimestamp"])/60)
            if (game['status']['type']!="finished" and mins < 120):
                gameStreams= self.acestreamLinkProvider.get_acestreams(game['id'])
                if (len(gameStreams)>0):
                    liveEvents+=1
        return liveEvents

    def prepare_stream_link(self, competition, liveEvents, plural):
        return (
            competition['id'], 
            competition['name'] + "  ("+str(liveEvents)+" event"+plural+")",
            competition['logo'])

    def get_competitions(self):
        gameData= self.gameDataProvider.get_game_data()
        competitions= []
        for competition in gameData:
            liveEvents = self.get_number_of_streaming_events(competition)
            if (liveEvents > 0):
                if (liveEvents > 1):
                    plural="s"
                else:
                    plural= ""
                competitions.append(self.prepare_stream_link(competition, liveEvents, plural))
        return competitions