import os, sys, re, json
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class StreamClient(object):
    def __init__(self, gameDataProvider, acestreamLinkProvider):
        self.gameDataProvider= gameDataProvider
        self.acestreamLinkProvider = acestreamLinkProvider

    def get_streams(self, game_id):
        streams=[]
        acestreams= self.acestreamLinkProvider.get_acestreams(game_id)
        game_name= ""
        gameData= self.gameDataProvider.get_game_data()
        for competition in gameData:
            for game in competition['events']:
                if (game['id']==int(game_id)):
                    game_name= game['name']+" - "
        for acestreamUrl, title in acestreams:
            if (title==None or title==""):
                title= "Unknown Stream"
            title= title.replace("\\", "")
            streams.append((acestreamUrl, title, game_name+title))
        return streams