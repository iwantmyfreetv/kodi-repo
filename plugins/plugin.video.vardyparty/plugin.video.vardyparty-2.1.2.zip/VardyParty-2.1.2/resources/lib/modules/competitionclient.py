import os
import sys
import re
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class CompetitionClient(object):
    def __init__(self, game_data_provider, acestream_link_provider):
        self.game_data_provider = game_data_provider
        self.acestream_link_provider = acestream_link_provider

    def get_number_of_streaming_events(self, competition):
        live_events = 0
        for game in competition['events']:
            if (self.game_data_provider.is_active_game(game)):
                gameStreams = self.acestream_link_provider.get_acestreams(game['id'])
                if (len(gameStreams) > 0):
                    live_events+=1
        return live_events

    def prepare_stream_link(self, competition, number_of_live_events):
        return (competition['id'], 
            self.game_data_provider.get_competition_title(competition, number_of_live_events),
            competition['logo'])

    def get_competitions(self):
        game_data = self.game_data_provider.get_game_data()
        competitions = []
        for competition in game_data:
            number_of_live_events = self.get_number_of_streaming_events(competition)
            if (number_of_live_events > 0):
                competitions.append(self.prepare_stream_link(competition, number_of_live_events))
        return competitions

    def non_competition_games(self):
        return len(self.acestream_link_provider.get_non_competition_games())