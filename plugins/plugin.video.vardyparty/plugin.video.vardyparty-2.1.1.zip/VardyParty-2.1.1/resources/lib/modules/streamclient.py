import os
import sys
import re
import json
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class StreamClient(object):
    def __init__(self, game_data_provider, acestream_link_provider):
        self.game_data_provider = game_data_provider
        self.acestream_link_provider = acestream_link_provider

    def clean_title(self, title):
        channel = ""
        language = ""
        resolution = ""
        if (title == None or title == ""):
            title = "Unknown Stream"
        title_components = title.lower().replace("-", " ").replace("\\", " ").replace("[", " ").replace("]"," ").replace('`', " ").replace("  ", " ").strip().split(" ")
        first = True
        title = ""
        acronym_pattern = r'^\w{2,3}$'
        resolution = ""
        language = ""
        for title_component in title_components:
            if (not first):
                title = title + " "
            else:
                first = False
            title_component = title_component.capitalize()
            if (title_component == 'Hd'):
                if  (not("1080" in title_components or "1080p" in title_components or "720" in title_components or "720p" in title_components)):
                    resolution = "HD"
                title_component = ""
            if (title_component == "Sd"):
                title_component = ""
                resolution = "SD"
            if (re.search(acronym_pattern, title_component) != None):
                title_component = title_component.upper()
                if (title_component != "BT" and title_component != "SKY"):
                     language = title_component
                     title_component = ""
            if (title_component == "720p"):
                title_component = "720"
            if (title_component == "1080p"):
                title_component = "1080"
            if (title_component == "720" or title_component == "1080"):
                resolution = title_component
                title_component = ""
            title = title + title_component
        title = title.strip()
        while (len(title) > len(title.replace("  ", " "))):
            title = title.replace("  ", " ")
        if (resolution != ""):
            prefix= " - " if title!="" else ""
            title = title + prefix + resolution
        if (language != ""):
            prefix= " - " if title!="" else ""
            title = title + " - " + language
        return title

    def get_streams(self, game_id):
        streams = []
        acestreams = self.acestream_link_provider.get_acestreams(game_id)
        game_name = self.game_data_provider.get_game_name(game_id)
        game = self.game_data_provider.get_game(game_id)
        game_score = ''
        if (game != None):
            game_score = self.game_data_provider.get_score_str(game)
        for url, title, source, type in acestreams:
            title = self.clean_title(title)
            streams.append((url, title, game_score + game_name + " - " + title, source, type, self.get_icon(source)))
        return streams

    def get_streams_from_title(self, title):
        streams = []
        for url, title, source, type in self.acestream_link_provider.get_acestream_items_from_title(title):
            streams.append((url, title, title, source, type, self.get_icon(source)))
        return streams

    def get_icon(self, source):
        if (source == 'footybites'):
            return 'footybites.png'
        if (source == "reddit"):
            return 'soccerstreams.png'
        if (source == 'rojadiecta'):
            return 'roja.pngg'
        return None