import os, sys, re, json
import urllib2
#handler=urllib2.httphandler(debuglevel=1)
#opener = urllib2.build_opener(handler)
#urllib2.install_opener(opener)
reload(sys)
                                            
try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

outer_pattern= r'(<a[\w\s=]+"acestream:[\/\w]+"[\s\w="]+>[\w\s]+<\/a>)'
title_pattern= r'<a[\w\s=]+"acestream:[\/\w]+"[\s\w="]+>([\w\s]+)<\/a>'
#title_pattern= r'>([\w\s]+)<'
acestream_pattern= r'(acestream://\w+)'
external_acestream_link_pattern= r'<a href="([\w:\/\.]+)" target="[_\w]+" rel="[\w]+">ACESTREAM.+<\/a>'

class FootyBiteStreamProvider(object):
    def __init__(self, web_content_provider):
        self.web_content_provider = web_content_provider

    def get_acestreams(self, url):
        content= self.web_content_provider.get_page(url)
        matches= re.findall(outer_pattern, content)
        matches.extend(re.findall(acestream_pattern, content))
        external_links= re.findall(external_acestream_link_pattern, content)
        for external_link in external_links:
            content= self.web_content_provider.get_page(external_link)
            matches.extend(re.findall(acestream_pattern, content))
        unique= set(matches)
        acestream_items= []
        for item in unique:
            title_match= re.findall(title_pattern, item)
            if (len(title_match)>0):
                title= title_match[0];
            else:
                title= None
            stream_url= re.findall(acestream_pattern, item)
            if (len(stream_url)>0):
                acestream_items.append((stream_url[0], title))
            else:
                log("DID NOT FIND ACESTREAM LINK IN "+item, 3)
        return acestream_items