import os, sys, re, json
import urllib2
#handler=urllib2.httphandler(debuglevel=1)
#opener = urllib2.build_opener(handler)
#urllib2.install_opener(opener)
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class AcestreamLinkProvider(object):
    def __init__(self, game_data_provider, reddit_stream_provider, footybite_stream_provider):
        self.game_data_provider = game_data_provider
        self.reddit_stream_provider = reddit_stream_provider
        self.footybite_stream_provider = footybite_stream_provider

    def normalise(self, link_set):
        normalised= {}
        for acestream_url, title in link_set:
            if (acestream_url not in normalised or normalised[acestream_url]==None):
                normalised[acestream_url]= title
        normalised_link_set=[]
        for key in normalised:
            normalised_link_set.append((key, normalised[key]))
        return normalised_link_set

    def get_acestreams(self, game_id):
        game_data=  self.game_data_provider.get_game_data()
        acestream_items=[]
        for competition in game_data:
            for event in competition['events']:
                if (str(event['id'])==str(game_id)):
                    fooybite_url= event['redditEventLink']
                    if (fooybite_url!=None):
                        acestream_items.extend(self.footybite_stream_provider.get_acestreams(fooybite_url))
                    acestream_items.extend(self.reddit_stream_provider.get_acestreams(event))
        return self.normalise(acestream_items)
