import os
import sys
import re
import json
import urllib2
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class RojadirectaStreamProvider(object):

    def __init__(self, web_content_provider, game_data_provider):
        self.web_content_provider = web_content_provider
        self.game_data_provider = game_data_provider
        self.index = 'http://www.rojadirecta.me.de.a2ip.ru/'

    def find_raw_acestream_text(eelf, content):
        #pattern = r'(acestream:\/\/\w+)'
        #matches = re.findall(pattern, content)
        links = []
        #for match in matches:
        #    links.append((match, None, 'rojadiecta', 'acestream'))
        return links

    def get_acestream(self, url):
        acestream_url = None
        #link_pattern = r'disabled. <a href="([\w:\/\.\-\?\#\*\s\_]+)"'
        #hosted_page_pattern = r'loadPlayer\("(\w+)"'
        #content = self.web_content_provider.get_page(url)
        #matches = re.findall(link_pattern, content)
        #if (len(matches) > 0):
        #    hosting_page = matches[0]
        #    content = self.web_content_provider.get_page(hosting_page)
        #    matches = re.findall(hosted_page_pattern, content)
        #    if (len(matches) > 0):
        #        acestream_url = "acestream://" + matches[0]
        #    else:
        #        log("FAILED TO FIND HASH: " + hosting_page, 3)
        #    acestream_links = self.find_raw_acestream_text(content)
        #    if (len(acestream_links) > 0):
        #        acestream_url = acestream_links[0][0]
        #    else:
        #        log("  AND NO INLINE ACESTREAM URL",3)
        #else:
        #    log("FAILED TO FIND HOSTED PAGE IN CONTENT: " + url, 3)
        #    acestream_links = self.find_raw_acestream_text(content)
        #    if (len(acestream_links) > 0):
        #        acestream_url = acestream_links[0][0]
        #    else:
        #        log("  AND NO INLINE ACESTREAM URL",3)
        return acestream_url

    def get_acestream_items_from_title(self, title):
        acestream_items = []
        #for game, content in self.get_all_games():
        #    if (title in game):
        #        acestream_items.extend(self.get_acestream_items_from_content(content))
        return acestream_items

    def get_all_games(self):
        games = []
        #content = self.web_content_provider.get_page(self.index)
        #game_pattern = r'<span itemprop="name">(?:<span class="es">[\w\s\-\d]+<\/span><span class="en">)?([\w\s\-\d]+)(?:<\/span> \- <span class="es">[\w\s\-\d]+<\/span><span class="en">)?([\w\s\-\d]+)<\/span>[\/<>\w\!\-\d\n\s="]+<table([\/<>\w\!\-\d\n\s="\(\)\\:\.\?\#\&;\'\,\*]*?)<\/table'
        #matches= re.findall(game_pattern, content)
        #for match in matches:
        #    if (" - " in match[0]):
        #        names= match[0].split(" - ")
        #        game_title = names[0] + " - " + names[1]
        #    elif (" - " in match[1]):
        #        names= match[1].split(" - ")
        #        game_title = names[0] + " - " + names[1]
        #    else:
        #        game_title = match[0] + " - " + match[1]
        #    games.append((game_title, match[2]))
        return games 

    def get_acestream_items_from_content(self, content):
        streams = []
        #stream_pattern = r'<td>P2P<\/td>[\n\s]+<td>([\w\s\-]+)<\/td>[\n\s]+<td>*([\w]+)<\/td>[\n\s]+<td>*[\w\s\(\)]+<\/td>[\n\s]+<td>([\w\s]+)<\/td>[\n\s]+<td>[<\w>\s="]+href="([\w:\/\.\-\?#]+)"'
        #stream_matches= re.findall(stream_pattern, content)
        #for stream_match in stream_matches:
        #    stream_name = "[" + stream_match[0] + "] [" + stream_match[1] + "] [" + stream_match[2] + "]"
        #    url = self.get_acestream(stream_match[3])
        #    if (url != None):
        #        streams.append((url, stream_name, "rojadiecta", "acestream"))
        return streams

    def get_acestreams(self, game):
        streams = []
        #for game_title, content in self.get_all_games():
        #    if (self.game_data_provider.game_title_matches_a_game_team(game_title, game)):
        #        acestream_items= self.get_acestream_items_from_content(content)
        #        streams.extend(acestream_items)
        return streams