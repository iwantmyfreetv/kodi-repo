import os
import sys
import re
import json
import urllib2
reload(sys)

try:
    from xbmc import log
except:
    def log(msg):
        print(msg)

class RojadirectaStreamProvider(object):

    def __init__(self, web_content_provider, game_data_provider):
        self.web_content_provider = web_content_provider
        self.game_data_provider = game_data_provider
        self.index = 'http://www.rojadirecta.me.de.a2ip.ru/'

    def get_acestream(self, url):
        acestream_url= None
        link_pattern= r'disabled. <a href="([\w:\/\.\-\?\#\*\s\_]+)"'
        hosted_page_pattern= r'loadPlayer\("(\w+)"'
        content=  self.web_content_provider.get_page(url)
        matches= re.findall(link_pattern, content)
        if (len(matches)>0):
            hosting_page= matches[0]
            content= self.web_content_provider.get_page(hosting_page)
            matches= re.findall(hosted_page_pattern, content)
            if (len(matches)>0):
                acestream_url= "acestream://"+matches[0]
            else:
                log("FAILED TO FIND HASH IN CONTENT: "+content, 3)
        else:
            log("FAILED TO FIND HOSTED PAGE IN CONTENT: "+content, 3)
        return acestream_url

    def get_acestreams(self, game):
        streams= []
        content= self.web_content_provider.get_page(self.index)
        game_pattern= r'<span itemprop="name"><span class="es">[\w\s\-\d]+<\/span><span class="en">([\w\s\-\d]+)<\/span> \- <span class="es">[\w\s\-\d]+<\/span><span class="en">([\w\s\-\d]+)<\/span>[\/<>\w\!\-\d\n\s="]+<table([\/<>\w\!\-\d\n\s="\(\)\\:\.\?\#\&;\'\,\*]*?)<\/table'
        stream_pattern= r'<td>P2P<\/td>[\n\s]+<td>([\w\s\-]+)<\/td>[\n\s]+<td>*([\w]+)<\/td>[\n\s]+<td>*[\w\s\(\)]+<\/td>[\n\s]+<td>([\w\s]+)<\/td>[\n\s]+<td>[<\w>\s="]+href="([\w:\/\.\-\?#]+)"'
        for match in re.findall(game_pattern, content):
            game_title= match[0]+" "+match[1]
            if (self.game_data_provider.game_title_matches_a_game_team(game_title, game)):
                log(game_title, 3)
                for stream_matches in re.findall(stream_pattern, match[2]):
                    stream_name= "["+stream_matches[0]+"] ["+stream_matches[1]+"] ["+stream_matches[2]+"]"
                    url= self.get_acestream(stream_matches[3])
                    if (url != None):
                        streams.append((url, stream_name, "rojadiecta", "acestream"))
        return streams