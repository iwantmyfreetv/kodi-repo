from __future__ import unicode_literals

import sys
import os
import urllib
reload(sys)
sys.setdefaultencoding('utf-8')

import xbmc
try:
    from xbmc import log
except:
    def log(msg):
        print(msg)
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory

from resources.lib.modules.addon import Addon
from resources.lib.modules import routing
from resources.lib.modules.log_utils import log

addon = Addon('plugin.video.vardyparty', sys.argv)
addon_handle = int(sys.argv[1])
plugin = routing.Plugin()
AddonPath = addon.get_path()
IconPath = os.path.join(AddonPath , "resources/media/")
fanart = os.path.join(AddonPath + "/fanart.jpg")

# Update path so that praw doesnt complain
sys.path.append(os.path.join(AddonPath, 'resources/lib/modules'))

from resources.lib.modules.competitionclient import CompetitionClient
from resources.lib.modules.gameclient import GameClient
from resources.lib.modules.streamclient import StreamClient
from resources.lib.modules.gamedataprovider.gamedataprovider import GameDataProvider
from resources.lib.modules.gamedataprovider.footybitestreamprovider import FootyBiteStreamProvider
from resources.lib.modules.gamedataprovider.redditstreamprovider import RedditStreamProvider
from resources.lib.modules.gamedataprovider.rojadirectastreamprovider import RojadirectaStreamProvider
from resources.lib.modules.subreddits import SubRedditEvents
from resources.lib.modules.gamedataprovider.acestreamlinkprovider import AcestreamLinkProvider
from resources.lib.modules.gamedataprovider.linkprovider import LinkProvider
from resources.lib.modules.gamedataprovider.webcontentprovider import WebContentProvider

AS_LAUNCH_LINK = 'XBMC.RunPlugin(plugin://program.plexus/?mode=1&url={url}&name={name})'

def icon_path(filename):
    if 'http://' in filename:
        return filename
    return os.path.join(IconPath, filename)

@plugin.route('/')
def index():
    addDirectoryItem(plugin.handle,
        plugin.url_for(competitions),
        ListItem("Acestreams"), True)
    addDirectoryItem(plugin.handle,
        plugin.url_for(links),
        ListItem("Links"), True)
    endOfDirectory(plugin.handle)

@plugin.route('/competitions')
def competitions():
    web_content_provider = WebContentProvider()
    game_data_provider = GameDataProvider(web_content_provider)
    competitionClient = CompetitionClient(game_data_provider,
        AcestreamLinkProvider(game_data_provider, 
            RedditStreamProvider(SubRedditEvents(), 
                web_content_provider,
                game_data_provider),
            FootyBiteStreamProvider(web_content_provider,
                game_data_provider),
            RojadirectaStreamProvider(web_content_provider,
                game_data_provider)))
    for url, title, icon in competitionClient.get_competitions():
        addDirectoryItem(plugin.handle,
            plugin.url_for(competition, competition_id=url, icon=urllib.quote(icon.encode('utf-8'), safe='')),
            ListItem(title, iconImage=icon), True)
    non_competition_games = competitionClient.non_competition_games()
    if non_competition_games > 0:
        plural = ''
        if non_competition_games > 1:
            plural = 's'
        addDirectoryItem(plugin.handle,
            plugin.url_for(no_competition),
            ListItem("No competition [" + str(non_competition_games) + " game" + plural + "]"), True)
    endOfDirectory(plugin.handle)

@plugin.route('/links')
def links():
    web_content_provider = WebContentProvider()
    link_provider = LinkProvider(web_content_provider)
    for item in link_provider.get_acestreams():
        url = None
        if (item['link'] != None and item['link'] != ''):
            url = plugin.url_for(play, 
                url=urllib.quote(item['link'].encode('utf-8'), safe=''),
                game=urllib.quote(item['title'].encode('utf-8'), safe=''),
                source="links",
                type="acestream")
        addDirectoryItem(plugin.handle,
            url,
            ListItem(item['title']), False)
    endOfDirectory(plugin.handle)

@plugin.route('/competition/<competition_id>/<icon>')
def competition(competition_id, icon):
    icon= urllib.unquote(icon).decode('utf-8')
    web_content_provider = WebContentProvider()
    game_data_provider = GameDataProvider(web_content_provider)
    game_client = GameClient(game_data_provider, 
        AcestreamLinkProvider(game_data_provider, 
            RedditStreamProvider(SubRedditEvents(), 
                web_content_provider,
                game_data_provider), 
            FootyBiteStreamProvider(web_content_provider,
                game_data_provider),
            RojadirectaStreamProvider(web_content_provider,
                game_data_provider)))
    for title, id in game_client.get_games(competition_id):
        addDirectoryItem(plugin.handle,
            plugin.url_for(game,id),
            ListItem(title, iconImage=icon), True)
    endOfDirectory(plugin.handle)

@plugin.route('/no_competition/')
def no_competition():
    web_content_provider = WebContentProvider()
    game_data_provider = GameDataProvider(web_content_provider)
    game_client = GameClient(game_data_provider, 
        AcestreamLinkProvider(game_data_provider, 
            RedditStreamProvider(SubRedditEvents(), 
                web_content_provider,
                game_data_provider), 
            FootyBiteStreamProvider(web_content_provider,
                game_data_provider),
            RojadirectaStreamProvider(web_content_provider,
                game_data_provider)))
    for title, display_title in game_client.get_non_competition_games():
        addDirectoryItem(plugin.handle,
            plugin.url_for(non_competition_game,
                game_title=urllib.quote(title.encode('utf-8'), safe='')),
            ListItem(display_title), True)
    endOfDirectory(plugin.handle)

@plugin.route('/game/<game_id>')
def game(game_id):
    web_content_provider = WebContentProvider()
    game_data_provider = GameDataProvider(web_content_provider)
    stream_client = StreamClient(game_data_provider,
        AcestreamLinkProvider(game_data_provider, 
            RedditStreamProvider(SubRedditEvents(),
                web_content_provider,
                game_data_provider), 
            FootyBiteStreamProvider(web_content_provider,
                game_data_provider),
            RojadirectaStreamProvider(web_content_provider,
                game_data_provider)))
    for acestream_link, title, game_title, source, type, stream_icon in stream_client.get_streams(game_id):
        xbmc.log("menu:" + acestream_link + " = " + title, 3)
        url = plugin.url_for(play,
            url= urllib.quote(acestream_link.encode('utf-8'), safe=''),
            game= urllib.quote(game_title.encode('utf-8'), safe=''),
            source= urllib.quote(source.encode('utf-8'), safe=''),
            type= urllib.quote(type.encode('utf-8'), safe=''))
        addDirectoryItem(plugin.handle,
            url,
            ListItem(title, iconImage= stream_icon), False)
    endOfDirectory(plugin.handle)

@plugin.route('/non_competition_game/<game_title>')
def non_competition_game(game_title):
    web_content_provider = WebContentProvider()
    game_data_provider = GameDataProvider(web_content_provider)
    stream_client = StreamClient(game_data_provider,
        AcestreamLinkProvider(game_data_provider, 
            RedditStreamProvider(SubRedditEvents(),
                web_content_provider,
                game_data_provider), 
            FootyBiteStreamProvider(web_content_provider,
                game_data_provider),
            RojadirectaStreamProvider(web_content_provider,
                game_data_provider)))
    game_title = urllib.unquote(game_title).decode('utf-8')
    for acestream_link, title, source, type, stream_icon in stream_client.get_streams_from_title(urllib.unquote(game_title).decode('utf-8')):
        link_title = game_title + " - " + title
        xbmc.log("menu:" + acestream_link + " = " + title, 3)
        url = plugin.url_for(play,
            url= urllib.quote(acestream_link.encode('utf-8'), safe=''),
            game= urllib.quote(game_title.encode('utf-8'), safe=''),
            source= urllib.quote(source.encode('utf-8'), safe=''),
            type= urllib.quote(type.encode('utf-8'), safe=''))
        addDirectoryItem(plugin.handle,
            url,
            ListItem(title, iconImage= stream_icon), False)
    endOfDirectory(plugin.handle)

@plugin.route('/play/<url>/<game>/<source>/<type>')
def play(url, game, source, type):
    url = urllib.unquote(url).decode('utf-8')
    game = urllib.unquote(game).decode('utf-8')
    source = urllib.unquote(source).decode('utf-8')    
    type = urllib.unquote(type).decode('utf-8')
    xbmc.log("Playing {} {} {}".format(url, source, type),3)
    try:
        xbmc.executebuiltin(AS_LAUNCH_LINK.format(url=url, name=game))
    except Exception as inst:
        xbmc.log(inst, 3)
    endOfDirectory(plugin.handle)

if __name__ == '__main__':
    plugin.run()